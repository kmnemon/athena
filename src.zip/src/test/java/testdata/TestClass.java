package testdata;

//1
//2
public class TestClass {
    public int a;
    //3
    public int b;

    /*abc
    xyz*/
    private void fn(int fn1, int fn2, int fn3){
         //haha
        int temp;
        System.out.println("what");
        System.out.println("hhah");
        //oo
    }

    private static class TT{
        public int ttx;
    }

}

class X{}
