package techdebt;

import object.Project;

public class Design {
    Project p;
}
